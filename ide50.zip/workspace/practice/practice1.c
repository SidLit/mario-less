#include <stdio.h>
#include <cs50.h>
#include <math.h>

int main(void)
{
    float co;

    do
    {
        co = get_float("change owed: ");
    }
    while (co <= 0);

    int cents = round(co * 100);
    int output = 0;
    int quarters;

    for (quarters = 0; cents >= 25; quarters++)
    {
        cents -= 25;
        output += 1;
    }
    int dimes;

    for (dimes = 0; cents >= 10; dimes++)
    {
        cents -= 10;
        output += 1;
    }
    int nickels;

    for (nickels = 0; cents >= 5; nickels++)
    {
        cents -= 5;
        output += 1;
    }
    int pennies;

    for (pennies = 0; cents >= 1; pennies++)
    {
        cents -= 1;
        output += 1;
    }
    printf("%i\n", output);

}



