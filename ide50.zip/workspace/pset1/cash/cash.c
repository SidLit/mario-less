#include<stdio.h>
#include<cs50.h>
#include<math.h>

int main(void)
//Print the least number of coins for change owed the user
{
    float co;

    //Prompt user for change owed
    do
    {
        co = get_float("change owed: ");
    }
    while (co <= 0);

    int cents = round(co * 100);
    int quarters;
    int output = 0;

    //Check to see if we can use quarters
    for (quarters = 0; cents >= 25; quarters++)
    {
        cents -= 25;
        output += 1;
    }
    int dimes;

    //Check to see if we can use dimes
    for (dimes = 0; cents >= 10; dimes++)
    {
        cents -= 10;
        output += 1;
    }
    int nickels;

    //Check to see if we can use nickels
    for (nickels = 0; cents >= 5; nickels++)
    {
        cents -= 5;
        output += 1;
    }
    int pennies;

    //Check to see if we can use pennies
    for (pennies = 0; cents >= 1; pennies++)
    {
        cents -= 1;
        output += 1;
    }
    printf("%i\n", output); //Print the least number of coins
}