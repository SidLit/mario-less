#include <stdio.h>

int main(void)

//print "hello, world"
{
    printf("hello, world\n");
}